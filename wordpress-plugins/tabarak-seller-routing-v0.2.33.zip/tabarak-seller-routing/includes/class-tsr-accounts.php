<?php
defined('ABSPATH') || exit;

/** Administrator-only branch credentials, scoped by the routing branch ID. */
final class TSR_Accounts {
    public static function has_linked_account($branch_id) {
        return (bool) get_users(array('meta_key' => Tabarak_Seller_Routing::BRANCH_META,
            'meta_value' => (int) $branch_id, 'fields' => 'ID', 'number' => 1));
    }

    private static function username($code) {
        return strtoupper(trim((string) $code));
    }

    public static function inspect($branches) {
        $rows = array();
        $seen = array();
        foreach ($branches as $branch) {
            $code = self::username($branch['code'] ?? '');
            $id = (int) ($branch['id'] ?? 0);
            $state = 'ready';
            $user = false;
            if (!$id || $code === 'D001' || !preg_match('/^[A-Z0-9_-]{2,40}$/D', $code) ||
                sanitize_user($code, true) !== $code || isset($seen[strtolower($code)])) {
                $state = 'invalid_or_duplicate_code';
            } else {
                $seen[strtolower($code)] = true;
                $user = get_user_by('login', $code);
                $linked = get_users(array('meta_key' => Tabarak_Seller_Routing::BRANCH_META,
                    'meta_value' => $id, 'fields' => 'all'));
                if (count($linked) > 1 || ($linked && (!$user || (int) $linked[0]->ID !== (int) $user->ID))) {
                    $state = 'branch_already_has_another_login';
                } elseif ($user) {
                    $assigned = (int) get_user_meta($user->ID, Tabarak_Seller_Routing::BRANCH_META, true);
                    if (!in_array('tabarak_seller', (array) $user->roles, true) || ($assigned && $assigned !== $id)) {
                        $state = 'username_in_use';
                    } else {
                        $state = $assigned === $id ? 'linked' : 'link_existing';
                    }
                }
            }
            $rows[] = array('branch' => $branch, 'username' => $code, 'state' => $state, 'user' => $user);
        }
        return $rows;
    }

    public static function render($branches) {
        if (!current_user_can('manage_options')) return;
        $rows = self::inspect($branches);
        $blocked = !$rows;
        echo '<hr><h2>Branch accounts</h2>';
        echo '<p>Username is the official branch code (for example T001). Each new account gets a separate, randomly generated password and access only to its linked branch. No email is stored on new branch accounts. Password recovery is handled by an administrator.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Branch</th><th>Username</th><th>Account</th><th>Admin action</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            if (!in_array($row['state'], array('ready', 'linked', 'link_existing'), true)) $blocked = true;
            $labels = array('ready' => 'Ready to create', 'linked' => 'Linked', 'link_existing' => 'Existing seller account; ready to link',
                'invalid_or_duplicate_code' => 'Code is retired, invalid or duplicated', 'branch_already_has_another_login' => 'Another login is linked',
                'username_in_use' => 'Username belongs to another account');
            echo '<tr><td>' . esc_html($row['branch']['name']) . '</td><td><code>' . esc_html($row['username']) . '</code></td><td>' . esc_html($labels[$row['state']]) . '</td><td>';
            if ($row['state'] === 'linked') {
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                wp_nonce_field('tsr_reset_account_' . (int) $row['branch']['id']);
                echo '<input type="hidden" name="action" value="tsr_reset_account"><input type="hidden" name="branch_id" value="' . (int) $row['branch']['id'] . '">';
                echo '<button class="button button-small" type="submit">Reset password and download CSV</button></form>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        if ($blocked) {
            echo '<p class="notice notice-warning">Resolve the account conflicts above before provisioning. No existing password will be changed.</p>';
            return;
        }
        echo '<p>Download the one-time password CSV immediately and store it securely. Existing linked accounts keep their current passwords and have an empty password cell. Repeating this action never rotates passwords.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('tsr_provision_accounts');
        echo '<input type="hidden" name="action" value="tsr_provision_accounts">';
        submit_button('Create missing branch accounts and download passwords CSV', 'primary', 'submit', false);
        echo '</form>';
    }

    public static function provision() {
        if (!current_user_can('manage_options')) wp_die('Administrator access required.', '', array('response' => 403));
        check_admin_referer('tsr_provision_accounts');
        $rows = self::inspect(Tabarak_Seller_Routing::branch_rows());
        if (!$rows) wp_die('No routing branches exist.', '', array('response' => 422));
        foreach ($rows as $row) {
            if (!in_array($row['state'], array('ready', 'linked', 'link_existing'), true)) {
                wp_die('Resolve branch account conflicts before provisioning. No accounts were created.', '', array('response' => 409));
            }
        }

        self::download_csv(self::create_accounts($rows));
    }

    public static function create_accounts($rows) {
        $results = array();
        foreach ($rows as $row) {
            $branch = $row['branch'];
            $code = $row['username'];
            $password = '';
            $status = $row['state'];
            if ($status === 'ready') {
                // 28 random alphanumeric characters avoid Excel formula interpretation.
                $password = wp_generate_password(28, false, false);
                $user_id = wp_insert_user(array('user_login' => $code, 'user_pass' => $password,
                    'user_email' => '', 'display_name' => $branch['name'], 'role' => 'tabarak_seller',
                    'meta_input' => array(Tabarak_Seller_Routing::BRANCH_META => (int) $branch['id'])));
                if (is_wp_error($user_id)) {
                    $password = '';
                    $status = 'creation_failed';
                } else {
                    $status = (int) get_user_meta($user_id, Tabarak_Seller_Routing::BRANCH_META, true) === (int) $branch['id']
                        ? 'created' : 'created_link_needs_review';
                }
            } elseif ($status === 'link_existing') {
                update_user_meta($row['user']->ID, Tabarak_Seller_Routing::BRANCH_META, (int) $branch['id']);
                $status = 'linked_existing_password_unchanged';
            } else {
                $status = 'already_linked_password_unchanged';
            }
            $results[] = array($code, $branch['name'], $code, $password, $status);
        }
        return $results;
    }

    public static function allow_password_reset($allow, $user_id) {
        $user = get_userdata((int) $user_id);
        return $user && in_array('tabarak_seller', (array) $user->roles, true) ? false : $allow;
    }

    public static function reset_password() {
        if (!current_user_can('manage_options')) wp_die('Administrator access required.', '', array('response' => 403));
        $branch_id = absint($_POST['branch_id'] ?? 0);
        check_admin_referer('tsr_reset_account_' . $branch_id);
        $branch = Tabarak_Seller_Routing::branch($branch_id);
        if (!$branch) wp_die('Branch not found.', '', array('response' => 404));
        $code = self::username($branch['code']);
        $user = get_user_by('login', $code);
        if (!$user || !in_array('tabarak_seller', (array) $user->roles, true) ||
            (int) get_user_meta($user->ID, Tabarak_Seller_Routing::BRANCH_META, true) !== $branch_id) {
            wp_die('Branch account is not linked.', '', array('response' => 409));
        }
        $password = wp_generate_password(28, false, false);
        wp_set_password($password, $user->ID);
        global $wpdb;
        $wpdb->delete(Tabarak_Seller_Routing::table('sessions'), array('user_id' => (int) $user->ID));
        self::download_csv(array(array($code, $branch['name'], $code, $password, 'password_reset')));
    }

    private static function download_csv($rows) {
        nocache_headers();
        header('Cache-Control: private, no-store, max-age=0');
        header('X-Content-Type-Options: nosniff');
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="tabarak-branch-credentials.csv"');
        $out = fopen('php://output', 'w');
        echo "\xEF\xBB\xBF";
        fputcsv($out, array('branch_code', 'branch_name', 'username', 'one_time_password', 'status'));
        foreach ($rows as $row) {
            $row = array_map(static function($value) {
                $value = (string) $value;
                return preg_match('/^[\s\x00-\x1f]*[=+@-]/u', $value) ? "'" . $value : $value;
            }, $row);
            fputcsv($out, $row);
        }
        fclose($out);
        exit;
    }
}
