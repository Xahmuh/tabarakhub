<?php
/**
 * Plugin Name: Tabarak Seller Routing
 * Description: WordPress-owned branch offers and first-accept dispatch for Tabarak Online orders.
 * Version: 0.2.33
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes/class-tsr-planner.php';
require_once __DIR__ . '/includes/class-tsr-api.php';
require_once __DIR__ . '/includes/class-tsr-order-edit-money.php';
require_once __DIR__ . '/includes/class-tsr-branch-transfer.php';
require_once __DIR__ . '/includes/class-tsr-accounts.php';
require_once __DIR__ . '/includes/class-tsr-pharmacists.php';

final class Tabarak_Seller_Routing {
    const NS = 'tabarak-seller/v1';
    const VERSION = '0.2.33';
    const BRANCH_META = '_tabarak_seller_branch_id';
    private static $instance;

    public static function instance() { return self::$instance ?: (self::$instance = new self()); }
    public static function table($suffix) { global $wpdb; return $wpdb->prefix . 'tabarak_seller_' . $suffix; }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        add_role('tabarak_seller', 'Tabarak seller', array('read' => true));
        $charset = $wpdb->get_charset_collate();
        $schemas = array(
            'branches' => "id bigint unsigned NOT NULL AUTO_INCREMENT, code varchar(40) NOT NULL, name varchar(150) NOT NULL, block_number varchar(8) NOT NULL DEFAULT '', lat decimal(10,7) NULL, lng decimal(10,7) NULL, enabled tinyint(1) NOT NULL DEFAULT 1, always_open tinyint(1) NOT NULL DEFAULT 1, card_enabled tinyint(1) NOT NULL DEFAULT 0, cod_enabled tinyint(1) NOT NULL DEFAULT 1, wallet_enabled tinyint(1) NOT NULL DEFAULT 1, accept_anywhere tinyint(1) NOT NULL DEFAULT 0, hours_json longtext NOT NULL, pharmacists_json longtext NOT NULL, pharmacist_codes_json longtext NOT NULL, phone varchar(40) NOT NULL DEFAULT '', whatsapp varchar(40) NOT NULL DEFAULT '', address varchar(255) NOT NULL DEFAULT '', locality varchar(150) NOT NULL DEFAULT '', source_post_id bigint unsigned NULL, updated_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY code (code), UNIQUE KEY source_post_id (source_post_id), KEY block_number (block_number)",
            'dispatch' => 'order_id bigint unsigned NOT NULL, state varchar(30) NOT NULL, wave tinyint unsigned NOT NULL DEFAULT 0, branch_id bigint unsigned NULL, claimed_by bigint unsigned NULL, claimed_at datetime NULL, updated_at datetime NOT NULL, PRIMARY KEY  (order_id), KEY state (state), KEY branch_id (branch_id)',
            'offers' => 'order_id bigint unsigned NOT NULL, branch_id bigint unsigned NOT NULL, state varchar(16) NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (order_id,branch_id), KEY branch_state (branch_id,state)',
            'events' => "id bigint unsigned NOT NULL AUTO_INCREMENT, order_id bigint unsigned NOT NULL, event_key varchar(60) NOT NULL, actor_id bigint unsigned NOT NULL DEFAULT 0, branch_id bigint unsigned NOT NULL DEFAULT 0, detail varchar(255) NOT NULL DEFAULT '', created_at datetime NOT NULL, PRIMARY KEY  (id), KEY order_events (order_id,id), KEY event_time (event_key,created_at)",
            'sessions' => 'token_hash char(64) NOT NULL, user_id bigint unsigned NOT NULL, password_fingerprint char(64) NOT NULL, expires_at bigint unsigned NOT NULL, PRIMARY KEY  (token_hash), KEY user_id (user_id), KEY expires_at (expires_at)',
            'notifications' => 'id bigint unsigned NOT NULL AUTO_INCREMENT, user_id bigint unsigned NOT NULL, event_key varchar(120) NOT NULL, order_id bigint unsigned NOT NULL, title varchar(160) NOT NULL, body varchar(255) NOT NULL, read_at datetime NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY user_event (user_id,event_key), KEY inbox (user_id,id)',
            'handoffs' => "order_id bigint unsigned NOT NULL, branch_id bigint unsigned NOT NULL, order_number varchar(80) NOT NULL, amount_fils bigint NOT NULL, currency varchar(8) NOT NULL DEFAULT 'BHD', block_number varchar(8) NOT NULL DEFAULT '', pharmacist varchar(150) NOT NULL DEFAULT '', handed_at datetime NOT NULL, financial_state varchar(20) NOT NULL DEFAULT 'active', PRIMARY KEY  (order_id), KEY branch_time (branch_id,handed_at), KEY financial_time (financial_state,handed_at)",
        );
        foreach ($schemas as $suffix => $columns) dbDelta('CREATE TABLE ' . self::table($suffix) . " (\n" . str_replace(', ', ",\n", $columns) . "\n) ENGINE=InnoDB {$charset};");
        delete_transient('tbh_active_branches_cache');
        delete_transient('tbh_all_branches_cache');
        update_option('tabarak_seller_routing_schema', self::VERSION, false);
    }

    public static function boot() {
        if (!class_exists('WooCommerce')) return;
        $app = self::instance();
        add_action('init', array($app, 'register_workflow_statuses'), 9);
        add_filter('wc_order_statuses', array($app, 'add_workflow_order_statuses'));
        add_filter('woocommerce_order_is_paid', array($app, 'paid_state_for_workflow'), 10, 2);
        add_filter('woocommerce_rest_prepare_shop_order_object', array($app, 'add_rest_fulfillment_state'), 10, 3);
        add_action('init', array($app, 'maybe_upgrade'));
        add_action('admin_menu', array($app, 'admin_menu'));
        add_action('admin_post_tsr_save_branch', array($app, 'save_branch'));
        add_action('admin_post_tsr_save_rules', array($app, 'save_rules'));
        add_action('admin_post_tsr_assign_account', array($app, 'assign_account'));
        add_action('admin_post_tsr_provision_accounts', array('TSR_Accounts', 'provision'));
        add_action('admin_post_tsr_reset_account', array('TSR_Accounts', 'reset_password'));
        add_filter('allow_password_reset', array('TSR_Accounts', 'allow_password_reset'), 10, 2);
        add_action('admin_post_tsr_manual_assign', array($app, 'manual_assign'));
        add_action('admin_post_tsr_retry_dispatch', array($app, 'retry_dispatch'));
        add_action('admin_post_tsr_export_branches', array('TSR_Branch_Transfer', 'export_csv'));
        add_action('admin_post_tsr_import_branches', array('TSR_Branch_Transfer', 'import_csv'));
        add_action('admin_post_tsr_import_pharmacists', array('TSR_Pharmacists', 'import_csv'));
        add_action('admin_post_tsr_import_pharmacist_assignments', array('TSR_Pharmacists', 'import_assignments'));
        add_action('admin_post_tsr_copy_directory', array('TSR_Branch_Transfer', 'copy_directory'));
        add_action('woocommerce_new_order', array($app, 'queue_order'), 20, 1);
        add_action('woocommerce_order_status_changed', array($app, 'status_changed'), 20, 4);
        add_action('tsr_dispatch_order', array($app, 'dispatch_order'), 10, 1);
        add_action('tsr_repeat_offer_alert', array($app, 'repeat_offer_alert'), 10, 3);
        add_filter('cron_schedules', array($app, 'driver_cancel_poll_schedule'));
        add_action('init', array($app, 'schedule_driver_cancel_poll'), 20);
        add_action('tsr_poll_driver_cancellations', array(new TSR_API($app), 'poll_driver_cancellations'));
        add_action('rest_api_init', array(new TSR_API($app), 'register_routes'));
        add_filter('rest_pre_dispatch', array($app, 'prevent_api_cache'), 0, 3);
    }

    public function maybe_upgrade() { if (get_option('tabarak_seller_routing_schema') !== self::VERSION) self::activate(); }
    public function driver_cancel_poll_schedule($schedules) {
        $schedules['tsr_driver_cancel_minute'] = array('interval' => 60, 'display' => 'Seller driver cancellation check');
        return $schedules;
    }
    public function schedule_driver_cancel_poll() {
        if (!wp_next_scheduled('tsr_poll_driver_cancellations'))
            wp_schedule_event(time() + 60, 'tsr_driver_cancel_minute', 'tsr_poll_driver_cancellations');
    }
    public function register_workflow_statuses() {
        foreach (array(
            'wc-seller-accepted' => 'Accepted by branch',
            'wc-seller-preparing' => 'Preparing',
            'wc-seller-ready' => 'Ready for pickup',
            'wc-handed-to-driver' => 'Handed to driver',
        ) as $status => $label) {
            register_post_status($status, array(
                'label' => $label,
                'public' => false,
                'exclude_from_search' => true,
                'show_in_admin_all_list' => true,
                'show_in_admin_status_list' => true,
                'label_count' => _n_noop($label . ' <span class="count">(%s)</span>', $label . ' <span class="count">(%s)</span>', 'tabarak-seller-routing'),
            ));
        }
    }
    public function add_workflow_order_statuses($statuses) {
        $statuses['wc-seller-accepted'] = 'Accepted by branch';
        $statuses['wc-seller-preparing'] = 'Preparing';
        $statuses['wc-seller-ready'] = 'Ready for pickup';
        $statuses['wc-handed-to-driver'] = 'Handed to driver';
        return $statuses;
    }
    public function paid_state_for_workflow($paid, $order) {
        if (!($order instanceof WC_Order) || !self::is_mobile_order($order)) return $paid;
        if (!in_array($order->get_status(), array('seller-accepted', 'seller-preparing', 'seller-ready', 'handed-to-driver'), true)) return $paid;
        return (bool) $order->get_date_paid();
    }
    /** Add a payment-independent lifecycle field to WooCommerce REST order responses. */
    public function add_rest_fulfillment_state($response, $order, $request) {
        if (!($response instanceof WP_REST_Response) || !($order instanceof WC_Order)) return $response;
        $state = self::fulfillment_state($order);
        $data = $response->get_data();
        $data['fulfillment_status'] = $state['status'];
        $data['fulfillment_label'] = $state['label'];
        $response->set_data($data);
        return $response;
    }
    public static function fulfillment_state($order) {
        $fulfillment = array(
            'seller-accepted' => array('under_review_and_preparation', 'Under review and preparation'),
            'seller-preparing' => array('under_review_and_preparation', 'Under review and preparation'),
            'seller-ready' => array('under_review_and_preparation', 'Under review and preparation'),
            'handed-to-driver' => array('scheduled_for_delivery', 'Scheduled for delivery'),
            'completed' => array('delivered', 'Delivered'),
            'cancelled' => array('cancelled', 'Cancelled'),
            'failed' => array('cancelled', 'Cancelled'),
            'refunded' => array('cancelled', 'Cancelled'),
        );
        $state = $fulfillment[$order->get_status()] ?? array('awaiting_branch', 'Waiting for branch confirmation');
        return array('status' => $state[0], 'label' => $state[1]);
    }
    public function sync_workflow_status($order, $dispatch) {
        if (!self::is_mobile_order($order) || !$dispatch || $dispatch['state'] !== 'claimed'
            || in_array($order->get_status(), array('completed', 'cancelled', 'failed', 'refunded'), true)) return;
        global $wpdb;
        $handed_at = $order->get_meta('_tabarak_seller_handed_at')
            ?: $wpdb->get_var($wpdb->prepare('SELECT handed_at FROM ' . self::table('handoffs') . ' WHERE order_id=%d', $order->get_id()));
        if ($handed_at) $status = 'handed-to-driver';
        elseif ($order->get_meta('_tabarak_seller_ready_at')) $status = 'seller-ready';
        elseif ($order->get_meta('_tabarak_seller_preparing_at')) $status = 'seller-preparing';
        elseif ($order->get_meta('_tabarak_seller_handed_at')) $status = 'handed-to-driver';
        else $status = 'seller-accepted';
        if ($order->get_status() !== $status) $order->update_status($status);
    }
    public function prevent_api_cache($result, $server, $request) {
        if (strpos($request->get_route(), '/' . self::NS . '/') !== 0) return $result;
        do_action('litespeed_control_set_nocache', 'Private Tabarak Seller API');
        nocache_headers();
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0', true);
        return $result;
    }
    public static function rules() {
        $raw = get_option('tabarak_seller_routing_rules', array());
        $raw = is_array($raw) ? $raw : array();
        return array('enabled' => !empty($raw['enabled']),
            'same_block_seconds' => min(600, max(15, (int) ($raw['same_block_seconds'] ?? 60))),
            'nearby_count' => min(20, max(1, (int) ($raw['nearby_count'] ?? 3))),
            'offer_timeout_seconds' => min(900, max(60, (int) ($raw['offer_timeout_seconds'] ?? 180))));
    }
    public static function readiness_issues() {
        $branches = self::branch_rows();
        if (!$branches) return array('No routing branches are configured.');
        $issues = array();
        $enabled_count = 0;
        foreach ($branches as $branch) {
            if (empty($branch['enabled'])) continue;
            $enabled_count++;
            $name = (string) $branch['name'];
            if (!TSR_Accounts::has_linked_account((int) $branch['id'])) $issues[] = $name . ': no linked seller account';
            $pharmacists = json_decode((string) ($branch['pharmacists_json'] ?? ''), true);
            if (!is_array($pharmacists) || !array_filter($pharmacists, static function($name) { return is_string($name) && trim($name) !== ''; })) $issues[] = $name . ': no pharmacist roster';
            if (empty($branch['block_number']) || !is_numeric($branch['lat']) || !is_numeric($branch['lng'])) $issues[] = $name . ': missing block or coordinates';
        }
        if ($enabled_count === 0) $issues[] = 'No routing branch is enabled.';
        return $issues;
    }
    public static function event($order_id, $key, $actor_id = 0, $branch_id = 0, $detail = '') {
        global $wpdb;
        $wpdb->insert(self::table('events'), array('order_id' => (int) $order_id, 'event_key' => sanitize_key($key), 'actor_id' => (int) $actor_id, 'branch_id' => (int) $branch_id, 'detail' => sanitize_text_field($detail), 'created_at' => current_time('mysql', true)));
    }
    public static function branch_rows() { global $wpdb; return $wpdb->get_results("SELECT * FROM " . self::table('branches') . " WHERE LOWER(code)<>'d001' ORDER BY name ASC", ARRAY_A) ?: array(); }
    public static function branch($id) { global $wpdb; $branch = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('branches') . ' WHERE id=%d', (int) $id), ARRAY_A); return $branch && strtolower($branch['code']) === 'd001' ? null : $branch; }
    public static function is_mobile_order($order) { return $order && in_array($order->get_created_via(), array('tabarak-mobile', 'propharm-mobile'), true); }
    public static function card_paid($order) {
        if ($order->get_payment_method() === 'tabarak_tap') return class_exists('Tabarak_Mobile_Tap') && Tabarak_Mobile_Tap::paid($order);
        return class_exists('Propharm_Mobile_Tap') && Propharm_Mobile_Tap::paid($order);
    }
    public static function wallet_paid($order) {
        if ($order->get_payment_method() === 'tabarak_twallet') {
            $total = (int) round((float) $order->get_total() * 1000);
            return $total >= 0 && (int) $order->get_meta('_tabarak_twallet_paid_fils') >= $total && $order->get_date_paid();
        }
        return $order->is_paid();
    }
    public static function block_for_order($order) {
        return preg_match('/(?:^|[;\n\r])\s*Block\s*:\s*(\d{2,4})\b/i', (string) $order->get_shipping_address_2(), $match) ? $match[1] : '';
    }
    public static function location_for_order($order) {
        $lat = $order->get_meta('delivery_lat', true); $lng = $order->get_meta('delivery_lng', true);
        if (!is_numeric($lat) || !is_numeric($lng)) return null;
        $lat = (float) $lat; $lng = (float) $lng;
        return $lat >= 25.5 && $lat <= 26.7 && $lng >= 50.2 && $lng <= 51.0 ? array($lat, $lng) : null;
    }
    public static function delivery_details($order) {
        $shipping = $order->get_address('shipping');
        $shipping = is_array($shipping) ? $shipping : array();
        $choices = array("Don't ring bell", 'Leave at door', 'Call on arrival', 'Leave at reception');
        $address_parts = array(); $instruction_parts = array();
        foreach (explode(';', (string) ($shipping['address_2'] ?? '')) as $part) {
            $part = trim($part);
            if ($part === '') continue;
            $matched = false;
            foreach ($choices as $choice) {
                if (strcasecmp($part, $choice) === 0) { $instruction_parts[] = $choice; $matched = true; break; }
            }
            if (!$matched) $address_parts[] = $part;
        }
        $shipping['address_2'] = implode('; ', $address_parts);
        $saved = method_exists($order, 'get_meta') ? trim((string) $order->get_meta('Delivery instructions')) : '';
        if ($saved !== '') $instruction_parts[] = $saved;
        return array('shipping' => $shipping, 'instructions' => implode("\n", array_values(array_unique($instruction_parts))));
    }
    public static function sync_driver_status($order) {
        if (!self::is_mobile_order($order) || !defined('TSR_DRIVER_BRIDGE_URL') || !defined('TSR_DRIVER_BRIDGE_SECRET')
            || !is_string(TSR_DRIVER_BRIDGE_SECRET) || strlen(TSR_DRIVER_BRIDGE_SECRET) < 32
            || !is_string(TSR_DRIVER_BRIDGE_URL) || wp_parse_url(TSR_DRIVER_BRIDGE_URL, PHP_URL_SCHEME) !== 'https'
            || !wp_http_validate_url(TSR_DRIVER_BRIDGE_URL)
            || !$order->get_meta('_tabarak_seller_delivery_order_id')
            || in_array($order->get_status(), array('completed', 'cancelled', 'failed', 'refunded'), true)) return;
        $order_id = (int) $order->get_id();
        $cache_key = 'tsr_driver_status_' . $order_id;
        if (get_transient($cache_key)) return;
        set_transient($cache_key, 1, 5);
        $response = wp_safe_remote_post(TSR_DRIVER_BRIDGE_URL, array(
            'timeout' => 3,
            'headers' => array('Content-Type' => 'application/json', 'X-Seller-Bridge-Secret' => TSR_DRIVER_BRIDGE_SECRET),
            'body' => wp_json_encode(array('action' => 'status', 'order_id' => (string) $order_id)),
        ));
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return;
        $result = json_decode(wp_remote_retrieve_body($response), true);
        $delivery = is_array($result) ? ($result['order'] ?? null) : null;
        if (!is_array($delivery) || (string) ($delivery['id'] ?? '') !== (string) $order->get_meta('_tabarak_seller_delivery_order_id')
            || !in_array($delivery['delivery_status'] ?? '', array('picked_up', 'delivered'), true)) return;
        $picked_at = strtotime((string) ($delivery['picked_up_at'] ?? '')) ?: strtotime((string) ($delivery['delivered_at'] ?? ''));
        $branch_id = (int) $order->get_meta('_tabarak_seller_branch_id');
        if ($picked_at && !$order->get_meta('_tabarak_seller_handed_at')) {
            global $wpdb;
            $handed_at = gmdate('Y-m-d H:i:s', $picked_at);
            $inserted = $wpdb->query($wpdb->prepare('INSERT IGNORE INTO ' . self::table('handoffs') .
                ' (order_id,branch_id,order_number,amount_fils,currency,block_number,pharmacist,handed_at,financial_state) VALUES (%d,%d,%s,%d,%s,%s,%s,%s,%s)',
                $order_id, $branch_id, (string) $order->get_order_number(), (int) round((float) $order->get_total() * 1000),
                (string) $order->get_currency(), self::block_for_order($order),
                (string) $order->get_meta('_tabarak_seller_pharmacist'), $handed_at, 'active'));
            if ($inserted !== false) {
                $order->update_meta_data('_tabarak_seller_handed_at', gmdate('c', $picked_at));
                $order->save();
                if ($inserted === 1) self::event($order_id, 'picked_up', 0, $branch_id, 'Driver confirmed pickup');
            }
        }
        if (($delivery['delivery_status'] ?? '') === 'delivered') {
            $delivered_at = strtotime((string) ($delivery['delivered_at'] ?? '')) ?: time();
            if (!$order->get_meta('_tabarak_seller_delivered_at')) {
                $order->update_meta_data('_tabarak_seller_delivered_at', gmdate('c', $delivered_at));
                $order->save();
            }
            if ($order->get_status() !== 'completed') {
                $order->update_status('completed', 'Delivery confirmed by Driver app.');
                self::event($order_id, 'delivered', 0, $branch_id, 'Driver confirmed delivery');
            }
            return;
        }
        if ($order->get_status() !== 'handed-to-driver') $order->update_status('handed-to-driver');
    }
    public function queue_order($order_id) { if (self::rules()['enabled']) $this->schedule($order_id, 10); }
    public function status_changed($order_id, $old, $new, $order) {
        if (!self::is_mobile_order($order)) return;
        if (in_array($new, array('seller-accepted', 'seller-preparing', 'seller-ready', 'handed-to-driver'), true)) return;
        if (in_array($new, array('cancelled', 'failed', 'refunded'), true)) {
            global $wpdb;
            $wpdb->update(self::table('handoffs'), array('financial_state' => $new), array('order_id' => (int) $order_id));
        }
        $enabled = self::rules()['enabled'];
        if (in_array($new, array('cancelled', 'failed', 'refunded', 'completed'), true)) {
            global $wpdb;
            // Keep a claimed branch assignment for the seller's order history.
            $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='closed',updated_at=%s WHERE order_id=%d AND state<>'claimed'", current_time('mysql', true), (int) $order_id));
            $wpdb->update(self::table('offers'), array('state' => 'closed'), array('order_id' => (int) $order_id, 'state' => 'open'));
            wp_clear_scheduled_hook('tsr_dispatch_order', array((int) $order_id));
            if ($enabled) self::notify_admins((int) $order_id, 'status:' . sanitize_key($new), 'Order #' . $order_id . ' is now ' . wc_get_order_status_name($new));
            return;
        }
        if (!$enabled) return;
        self::notify_admins((int) $order_id, 'status:' . sanitize_key($new), 'Order #' . $order_id . ' is now ' . wc_get_order_status_name($new));
        global $wpdb;
        $state = $wpdb->get_var($wpdb->prepare('SELECT state FROM ' . self::table('dispatch') . ' WHERE order_id=%d', (int) $order_id));
        if (!$state || in_array($state, array('pending', 'needs_location', 'waiting_for_open'), true)) $this->schedule($order_id, 10);
    }
    public function schedule($order_id, $seconds) {
        $args = array((int) $order_id);
        $target = time() + max(1, (int) $seconds);
        $existing = wp_next_scheduled('tsr_dispatch_order', $args);
        if ($existing && $existing <= $target) return;
        if ($existing) wp_unschedule_event($existing, 'tsr_dispatch_order', $args);
        wp_schedule_single_event($target, 'tsr_dispatch_order', $args);
    }
    public function dispatch_order($order_id) {
        global $wpdb;
        $rules = self::rules();
        if (!$rules['enabled']) return;
        $order = wc_get_order((int) $order_id);
        if (!self::is_mobile_order($order) || in_array($order->get_status(), array('cancelled', 'failed', 'refunded', 'completed'), true)) return;
        $payment = TSR_Planner::payment_kind($order);
        if ($payment === 'unsupported') { self::notify_admins($order_id, 'payment', 'Unsupported payment method'); return; }
        if ($payment === 'card' && !self::card_paid($order)) return;
        if ($payment === 'wallet' && !self::wallet_paid($order)) return;
        $now = current_time('mysql', true);
        $wpdb->query($wpdb->prepare('INSERT IGNORE INTO ' . self::table('dispatch') . ' (order_id,state,wave,updated_at) VALUES (%d,%s,0,%s)', $order_id, 'pending', $now));
        $dispatch = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('dispatch') . ' WHERE order_id=%d', $order_id), ARRAY_A);
        if (!$dispatch || in_array($dispatch['state'], array('claimed', 'closed', 'needs_admin'), true)) return;
        $wave = (int) $dispatch['wave'];
        if ($dispatch['state'] === 'offered' && in_array($wave, array(1, 2), true)) {
            $open = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . self::table('offers') . " WHERE order_id=%d AND state='open'", $order_id));
            $duration = $wave === 1 ? $rules['same_block_seconds'] : $rules['offer_timeout_seconds'];
            $remaining = TSR_Planner::remaining_offer_seconds((string) $dispatch['updated_at'], $duration, $open);
            if ($remaining > 0) {
                $this->schedule($order_id, $remaining);
                return;
            }
            if ($wave === 2) {
                $closed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='needs_admin',updated_at=%s WHERE order_id=%d AND state='offered' AND wave=2 AND branch_id IS NULL", $now, $order_id));
                if ($closed === 1) {
                    $wpdb->update(self::table('offers'), array('state' => 'expired'), array('order_id' => $order_id, 'state' => 'open'));
                    self::notify_admins($order_id, 'no_acceptance', 'Order needs manual branch assignment');
                }
                return;
            }
            $wpdb->update(self::table('offers'), array('state' => 'expired'), array('order_id' => $order_id, 'state' => 'open'));
        }
        $location = self::location_for_order($order);
        if (!$location) {
            $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='needs_location',updated_at=%s WHERE order_id=%d AND branch_id IS NULL AND state IN ('pending','waiting_for_open','offered')", $now, $order_id));
            if ($changed === 1) self::notify_admins($order_id, 'location', 'Order needs a delivery location');
            return;
        }
        $ranked = TSR_Planner::rank(self::branch_rows(), $payment, self::block_for_order($order), $location[0], $location[1]);
        if (!$ranked) {
            $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='needs_admin',updated_at=%s WHERE order_id=%d AND branch_id IS NULL AND state IN ('pending','needs_location','waiting_for_open','offered')", $now, $order_id));
            if ($changed === 1) {
                $wpdb->update(self::table('offers'), array('state' => 'expired'), array('order_id' => $order_id, 'state' => 'open'));
                self::notify_admins($order_id, 'no_payment_branch', 'No branch is configured for this payment method');
            }
            return;
        }
        $eligible = array_values(array_filter($ranked, static function($branch) { return $branch['is_open']; }));
        if (!$eligible) {
            $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='waiting_for_open',updated_at=%s WHERE order_id=%d AND branch_id IS NULL AND state IN ('pending','needs_location','waiting_for_open','offered')", $now, $order_id));
            if ($changed === 1) {
                self::notify_admins($order_id, 'closed', 'No eligible branch is open');
                $this->schedule($order_id, 15 * MINUTE_IN_SECONDS);
            }
            return;
        }
        if ($wave === 1) $wpdb->update(self::table('offers'), array('state' => 'expired'), array('order_id' => $order_id, 'state' => 'open'));
        $previous = $wave === 1 ? $wpdb->get_col($wpdb->prepare('SELECT branch_id FROM ' . self::table('offers') . ' WHERE order_id=%d', $order_id)) : array();
        $choice = TSR_Planner::offer_wave($eligible, $wave, $previous, $rules['nearby_count']);
        $offers = $choice['offers']; $next_wave = $choice['wave'];
        if (!$offers) {
            $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='needs_admin',updated_at=%s WHERE order_id=%d AND wave=%d AND branch_id IS NULL AND state IN ('pending','needs_location','waiting_for_open','offered')", $now, $order_id, $wave));
            if ($changed === 1) self::notify_admins($order_id, 'no_acceptance', 'Order needs manual branch assignment');
            return;
        }
        $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='offered',wave=%d,updated_at=%s WHERE order_id=%d AND wave=%d AND branch_id IS NULL AND state IN ('pending','needs_location','waiting_for_open','offered')", $next_wave, $now, $order_id, $wave));
        if ($changed !== 1) return;
        $retry_number = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . self::table('events') . " WHERE order_id=%d AND event_key='retry_dispatch'", $order_id));
        $offer_event = 'offer:' . $next_wave . ($retry_number ? ':retry' . $retry_number : '');
        foreach ($offers as $branch) {
            $created = $wpdb->query($wpdb->prepare('INSERT INTO ' . self::table('offers') . ' (order_id,branch_id,state,created_at) VALUES (%d,%d,%s,%s) ON DUPLICATE KEY UPDATE state=IF(state=%s,%s,state)', $order_id, $branch['id'], 'open', $now, 'expired', 'open'));
            if ($created) {
                self::notify_branch((int) $branch['id'], $order_id, $offer_event, 'New order available');
                $this->schedule_offer_alert((int) $order_id, (int) $branch['id'], $now);
            }
        }
        self::notify_admins($order_id, 'new', 'New order #' . $order->get_order_number());
        $this->schedule($order_id, $next_wave === 1 ? $rules['same_block_seconds'] : $rules['offer_timeout_seconds']);
    }

    private static function notify($user_id, $order_id, $event_key, $title) {
        global $wpdb;
        $created = $wpdb->insert(self::table('notifications'), array('user_id' => $user_id, 'event_key' => $event_key, 'order_id' => $order_id, 'title' => $title, 'body' => 'Open Tabarak Seller for the latest order status.', 'created_at' => current_time('mysql', true)));
        if (!$created) return;
        self::push_user((int) $user_id, (int) $order_id, $title);
    }
    private static function push_user($user_id, $order_id, $title) {
        $tokens = get_user_meta($user_id, '_tabarak_seller_push_tokens', true);
        if (!is_array($tokens)) return;
        $messages = array();
        foreach (array_slice(array_unique($tokens), 0, 3) as $token) if (is_string($token) && preg_match('/^ExpoPushToken\[[A-Za-z0-9_-]{8,128}\]$/', $token)) $messages[] = array('to' => $token, 'title' => $title, 'body' => 'Open Tabarak Seller for details.', 'data' => array('orderId' => $order_id), 'sound' => 'order_alarm.wav', 'channelId' => 'orders-alarm-v2', 'priority' => 'high');
        if ($messages) wp_remote_post('https://exp.host/--/api/v2/push/send', array('headers' => array('Content-Type' => 'application/json'), 'body' => wp_json_encode($messages), 'timeout' => 5, 'blocking' => false));
    }
    private function schedule_offer_alert($order_id, $branch_id, $generation) {
        $args = array((int) $order_id, (int) $branch_id, (string) $generation);
        if (!wp_next_scheduled('tsr_repeat_offer_alert', $args)) {
            wp_schedule_single_event(time() + 30, 'tsr_repeat_offer_alert', $args);
        }
    }
    public function repeat_offer_alert($order_id, $branch_id, $generation) {
        global $wpdb;
        if (!self::rules()['enabled']) return;
        $dispatch = $wpdb->get_row($wpdb->prepare('SELECT state,wave,branch_id,updated_at FROM ' . self::table('dispatch') . ' WHERE order_id=%d', (int) $order_id), ARRAY_A);
        if (!$dispatch || $dispatch['state'] !== 'offered' || $dispatch['branch_id'] !== null
            || (string) $dispatch['updated_at'] !== (string) $generation
            || !TSR_Planner::offer_is_active($dispatch, self::rules())) return;
        $offer = $wpdb->get_row($wpdb->prepare('SELECT state FROM ' . self::table('offers') . ' WHERE order_id=%d AND branch_id=%d', (int) $order_id, (int) $branch_id), ARRAY_A);
        if (!$offer || $offer['state'] !== 'open') return;
        $users = get_users(array('role' => 'tabarak_seller', 'meta_key' => self::BRANCH_META, 'meta_value' => (int) $branch_id, 'fields' => 'ID'));
        foreach ($users as $user_id) self::push_user((int) $user_id, (int) $order_id, 'New order available');
        $this->schedule_offer_alert((int) $order_id, (int) $branch_id, (string) $generation);
    }
    public static function notify_branch($branch_id, $order_id, $event, $title) {
        foreach (get_users(array('role' => 'tabarak_seller', 'meta_key' => self::BRANCH_META, 'meta_value' => $branch_id, 'fields' => 'ID')) as $user_id) self::notify((int) $user_id, $order_id, $event . ':' . $order_id . ':' . $branch_id, $title);
    }
    public static function notify_admins($order_id, $event, $title) {
        foreach (get_users(array('role__in' => array('administrator', 'shop_manager'), 'fields' => 'ID')) as $user_id) self::notify((int) $user_id, $order_id, $event . ':' . $order_id, $title);
    }
    public function admin_menu() { add_submenu_page('woocommerce', 'Tabarak Seller Routing', 'Seller Routing', 'manage_woocommerce', 'tabarak-seller-routing', array($this, 'admin_page')); }

    public function admin_page() {
        if (!current_user_can('manage_woocommerce')) wp_die('Forbidden');
        $rules = self::rules(); $branches = self::branch_rows(); $selected = null;
        if (isset($_GET['branch'])) foreach ($branches as $branch) if ((int) $branch['id'] === absint($_GET['branch'])) $selected = $branch;
        echo '<div class="wrap"><h1>Tabarak Seller Routing</h1><p>WordPress owns dispatch. Distance only ranks; it never disqualifies an address. Card eligibility must be enabled only for Tabarak branches.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
        if (isset($_GET['retry_order'], $_GET['retry_state'])) {
            $retry_order = absint($_GET['retry_order']);
            $retry_state = sanitize_key(wp_unslash($_GET['retry_state']));
            echo '<div class="notice notice-' . ($retry_state === 'offered' ? 'success' : 'warning') . '"><p>Order #' . $retry_order . ' routing state: ' . esc_html($retry_state) . '.</p></div>';
        }
        $issues = self::readiness_issues();
        if ($issues) echo '<div class="notice notice-warning"><p>Automatic dispatch is not ready: ' . count($issues) . ' branch setup issues. ' . esc_html(implode('; ', array_slice($issues, 0, 3))) . (count($issues) > 3 ? '; …' : '') . '</p></div>';
        if (!array_filter($branches, static function($branch) { return !empty($branch['enabled']) && !empty($branch['card_enabled']); })) echo '<div class="notice notice-info"><p>No branch currently accepts confirmed Tap card orders. These orders will require admin assignment until an approved Tabarak branch enables Card.</p></div>';
        echo '<h2>Global dispatch</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('tsr_rules');
        echo '<input type="hidden" name="action" value="tsr_save_rules"><p><label><input type="checkbox" name="enabled" value="1" ' . checked($rules['enabled'], true, false) . '> Enable automatic dispatch (leave off until branches are configured)</label></p>';
        echo '<p>Same-block exclusive window <input type="number" name="same_block_seconds" min="15" max="600" value="' . (int) $rules['same_block_seconds'] . '"> seconds</p><p>Nearest branches per wave <input type="number" name="nearby_count" min="1" max="20" value="' . (int) $rules['nearby_count'] . '"></p>';
        echo '<p>Nearby-offer response window <input type="number" name="offer_timeout_seconds" min="60" max="900" value="' . (int) $rules['offer_timeout_seconds'] . '"> seconds</p>';
        submit_button('Save dispatch rules'); echo '</form><hr>';
        echo '<h2>Retry an existing mobile order</h2><p>Run routing for an unassigned order that was not routed or whose offers expired. This sends new offers using the current rules.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('tsr_retry_dispatch');
        echo '<input type="hidden" name="action" value="tsr_retry_dispatch"><label>Order ID <input type="number" name="order_id" min="1" required></label> ';
        submit_button('Run routing', 'secondary', 'submit', false); echo '</form><hr><h2>Branches</h2>';
        echo '<p class="description">Card means this branch may receive an order already paid by Tap; it does not describe a card machine at the branch. New branches default to No. Open means Enabled and within the saved Bahrain opening hours right now.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Branch</th><th>Block</th><th>Enabled</th><th>Card</th><th>COD</th><th>Wallet</th><th>Anywhere</th><th>Open now</th><th>Action</th></tr></thead><tbody>';
        foreach ($branches as $branch) {
            $edit_url = admin_url('admin.php?page=tabarak-seller-routing&branch=' . (int) $branch['id']) . '#tsr-branch-editor';
            echo '<tr><td><a href="' . esc_url($edit_url) . '">' . esc_html($branch['name']) . '</a></td><td>' . esc_html($branch['block_number']) . '</td><td>' . ($branch['enabled'] ? 'Yes' : 'No') . '</td><td>' . ($branch['card_enabled'] ? 'Yes' : 'No') . '</td><td>' . ($branch['cod_enabled'] ? 'Yes' : 'No') . '</td><td>' . ($branch['wallet_enabled'] ? 'Yes' : 'No') . '</td><td>' . ($branch['accept_anywhere'] ? 'Yes' : 'No') . '</td><td>' . (TSR_Planner::is_open($branch) ? 'Yes' : 'No') . '</td><td><a class="button button-small" href="' . esc_url($edit_url) . '">Edit</a></td></tr>';
        }
        echo '</tbody></table>';
        echo '<hr><h3 id="tsr-branch-editor">' . ($selected ? 'Edit branch: ' . esc_html($selected['name']) : 'Add branch') . '</h3>';
        if ($selected) {
            echo '<p><a href="' . esc_url(admin_url('admin.php?page=tabarak-seller-routing#tsr-branch-editor')) . '">Back to add branch</a></p>';
            if (!empty($selected['source_post_id'])) {
                echo '<p class="description">This branch came from Our Branches. Copying Our Branches again refreshes its name, block, coordinates, contacts, hours and Enabled setting. Card, COD, Wallet, Anywhere and pharmacists stay as edited here. <a href="' . esc_url(admin_url('post.php?post=' . (int) $selected['source_post_id'] . '&action=edit')) . '">Edit source branch</a></p>';
            }
        }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('tsr_branch');
        echo '<input type="hidden" name="action" value="tsr_save_branch"><input type="hidden" name="branch_id" value="' . (int) ($selected['id'] ?? 0) . '">';
        foreach (array('code' => 'Stable branch code', 'name' => 'Branch name', 'block_number' => 'Origin block', 'lat' => 'Latitude', 'lng' => 'Longitude') as $key => $label) {
            $required = $key !== 'block_number' || !$selected || !empty($selected['enabled']);
            $locked = $key === 'code' && $selected && TSR_Accounts::has_linked_account($selected['id']);
            echo '<p><label>' . esc_html($label) . ' <input name="' . esc_attr($key) . '" value="' . esc_attr((string) ($selected[$key] ?? '')) . '"' . ($required ? ' required' : '') . ($locked ? ' readonly' : '') . '></label></p>';
        }
        foreach (array('phone' => 'Direct phone', 'whatsapp' => 'WhatsApp', 'address' => 'Address', 'locality' => 'Area / locality') as $key => $label) echo '<p><label>' . esc_html($label) . ' <input name="' . esc_attr($key) . '" value="' . esc_attr((string) ($selected[$key] ?? '')) . '"></label></p>';
        foreach (array('enabled' => 'Enabled', 'always_open' => '24 hours', 'card_enabled' => 'Accept Card', 'cod_enabled' => 'Accept COD', 'wallet_enabled' => 'Accept Wallet', 'accept_anywhere' => 'Receive offers from any block') as $key => $label) {
            $default = in_array($key, array('enabled', 'always_open', 'cod_enabled', 'wallet_enabled'), true);
            echo '<p><label><input type="checkbox" name="' . esc_attr($key) . '" value="1" ' . checked($selected ? !empty($selected[$key]) : $default, true, false) . '> ' . esc_html($label) . '</label></p>';
        }
        $hours = $selected ? json_decode($selected['hours_json'], true) : array();
        echo '<p>Hours (Bahrain time; up to three periods per day; HH:MM including 24:00 as an end time)</p>';
        foreach (array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday') as $day => $label) {
            echo '<p>' . esc_html($label) . ' ';
            foreach (range(0, 2) as $index) {
                $slot = $hours[(string) $day][$index] ?? array('', '');
                echo '<input type="text" inputmode="numeric" maxlength="5" size="5" placeholder="HH:MM" name="open[' . $day . '][' . $index . ']" value="' . esc_attr($slot[0] ?? '') . '"> to ';
                echo '<input type="text" inputmode="numeric" maxlength="5" size="5" placeholder="HH:MM" name="close[' . $day . '][' . $index . ']" value="' . esc_attr($slot[1] ?? '') . '"> ';
            }
            echo '</p>';
        }
        echo '<p><label>Pharmacists (one name per line; Hub codes are kept internally)<br><textarea name="pharmacists" rows="5" cols="50">' . esc_textarea(implode("\n", (array) json_decode($selected['pharmacists_json'] ?? '[]', true))) . '</textarea></label></p>';
        echo '<p class="description">Accept Card permits confirmed Tap card orders to route here. Enable it only for a Tabarak branch approved to fulfil these prepaid orders.</p>';
        submit_button($selected ? 'Save changes' : 'Save branch'); echo '</form>';
        TSR_Branch_Transfer::render();
        TSR_Accounts::render($branches);
        TSR_Pharmacists::render();
        if (current_user_can('manage_options')) {
        echo '<hr><h2>Assign existing branch login</h2><p>For an existing Tabarak seller user only. New accounts use the official branch code as the username. Never put staff passwords in the app.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('tsr_account');
        echo '<input type="hidden" name="action" value="tsr_assign_account"><select name="user_id" required><option value="">Seller account</option>';
        foreach (get_users(array('role' => 'tabarak_seller')) as $user) echo '<option value="' . (int) $user->ID . '">' . esc_html($user->user_login) . '</option>';
        echo '</select> <select name="branch_id" required><option value="">Branch</option>';
        foreach ($branches as $branch) echo '<option value="' . (int) $branch['id'] . '">' . esc_html($branch['name']) . '</option>';
        echo '</select>'; submit_button('Link account', 'secondary', 'submit', false); echo '</form>';
        }
        global $wpdb;
        $exceptions = $wpdb->get_results('SELECT order_id,state,updated_at FROM ' . self::table('dispatch') . " WHERE state IN ('needs_location','waiting_for_open','needs_admin','pending') ORDER BY updated_at DESC LIMIT 30", ARRAY_A);
        echo '<hr><h2>Needs admin attention</h2><table class="widefat striped"><thead><tr><th>Order</th><th>Reason</th><th>Updated UTC</th><th>Manual assignment</th></tr></thead><tbody>';
        foreach ($exceptions as $row) {
            echo '<tr><td><a href="' . esc_url(admin_url('admin.php?page=wc-orders&action=edit&id=' . $row['order_id'])) . '">#' . (int) $row['order_id'] . '</a></td><td>' . esc_html($row['state']) . '</td><td>' . esc_html($row['updated_at']) . '</td><td><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('tsr_manual_assign_' . $row['order_id']);
            echo '<input type="hidden" name="action" value="tsr_manual_assign"><input type="hidden" name="order_id" value="' . (int) $row['order_id'] . '"><select name="branch_id" required><option value="">Choose branch</option>';
            foreach ($branches as $branch) if ($branch['enabled']) echo '<option value="' . (int) $branch['id'] . '">' . esc_html($branch['name']) . '</option>';
            echo '</select> <button class="button">Assign</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function save_rules() {
        if (!current_user_can('manage_woocommerce')) wp_die('Forbidden', '', array('response' => 403));
        check_admin_referer('tsr_rules');
        if (isset($_POST['enabled'])) {
            $issues = self::readiness_issues();
            if ($issues) wp_die('Automatic dispatch needs linked seller accounts, pharmacist rosters, and valid locations for every enabled branch. Fix ' . count($issues) . ' branch setup issues first.', '', array('response' => 422));
        }
        update_option('tabarak_seller_routing_rules', array('enabled' => isset($_POST['enabled']),
            'same_block_seconds' => min(600, max(15, absint($_POST['same_block_seconds'] ?? 60))),
            'nearby_count' => min(20, max(1, absint($_POST['nearby_count'] ?? 3))),
            'offer_timeout_seconds' => min(900, max(60, absint($_POST['offer_timeout_seconds'] ?? 180)))), false);
        wp_safe_redirect(admin_url('admin.php?page=tabarak-seller-routing&saved=1')); exit;
    }
    public function retry_dispatch() {
        if (!current_user_can('manage_woocommerce')) wp_die('Forbidden', '', array('response' => 403));
        check_admin_referer('tsr_retry_dispatch');
        if (!self::rules()['enabled']) wp_die('Enable automatic dispatch before retrying an order.', '', array('response' => 409));
        $order_id = absint($_POST['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        if (!self::is_mobile_order($order)) wp_die('Choose an existing mobile order.', '', array('response' => 422));
        if (in_array($order->get_status(), array('cancelled', 'failed', 'refunded', 'completed'), true)) wp_die('This order is closed.', '', array('response' => 409));
        global $wpdb;
        $state = $wpdb->get_var($wpdb->prepare('SELECT state FROM ' . self::table('dispatch') . ' WHERE order_id=%d', $order_id));
        if ($state === 'needs_admin') {
            $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='pending',wave=0,updated_at=%s WHERE order_id=%d AND state='needs_admin' AND branch_id IS NULL", current_time('mysql', true), $order_id));
            if ($changed !== 1) wp_die('This order is no longer available for retry.', '', array('response' => 409));
            wp_clear_scheduled_hook('tsr_dispatch_order', array($order_id));
            self::event($order_id, 'retry_dispatch', get_current_user_id());
        } elseif ($state && !in_array($state, array('pending', 'needs_location', 'waiting_for_open'), true)) wp_die('This order already has a routing outcome.', '', array('response' => 409));
        $this->dispatch_order($order_id);
        $state = $wpdb->get_var($wpdb->prepare('SELECT state FROM ' . self::table('dispatch') . ' WHERE order_id=%d', $order_id));
        if (!$state) wp_die('Routing could not start. Check that the payment method is supported and any required payment is confirmed.', '', array('response' => 409));
        wp_safe_redirect(admin_url('admin.php?page=tabarak-seller-routing&retry_order=' . $order_id . '&retry_state=' . rawurlencode($state))); exit;
    }
    public function save_branch() {
        if (!current_user_can('manage_woocommerce')) wp_die('Forbidden', '', array('response' => 403));
        check_admin_referer('tsr_branch');
        global $wpdb;
        $id = absint($_POST['branch_id'] ?? 0);
        $code = sanitize_key(wp_unslash($_POST['code'] ?? '')); $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        if ($code === 'd001') wp_die('District branch is retired.', '', array('response' => 409));
        $original = $id ? self::branch($id) : null;
        if ($original && $original['code'] !== $code && TSR_Accounts::has_linked_account($id)) wp_die('Branch code cannot change while an account is linked.', '', array('response' => 409));
        $block = preg_replace('/\D/', '', (string) wp_unslash($_POST['block_number'] ?? ''));
        $lat = filter_var(wp_unslash($_POST['lat'] ?? ''), FILTER_VALIDATE_FLOAT); $lng = filter_var(wp_unslash($_POST['lng'] ?? ''), FILTER_VALIDATE_FLOAT);
        $enabled = isset($_POST['enabled']);
        if (!$code || !$name || ($block === '' ? $enabled : !preg_match('/^\d{2,4}$/', $block)) || $lat === false || $lng === false || $lat < 25.5 || $lat > 26.7 || $lng < 50.2 || $lng > 51.0) wp_die('Enter a valid Bahrain branch, block, and coordinates. Enabled branches require a block.', '', array('response' => 422));
        $hours = array();
        foreach (range(0, 6) as $day) {
            foreach (range(0, 2) as $slot) {
                $start = sanitize_text_field(wp_unslash($_POST['open'][$day][$slot] ?? ''));
                $end = sanitize_text_field(wp_unslash($_POST['close'][$day][$slot] ?? ''));
                if ($start !== '' || $end !== '') {
                    if (TSR_Planner::minutes_since_midnight($start) === null || $start === '24:00' ||
                        TSR_Planner::minutes_since_midnight($end) === null || $start === $end) wp_die('Invalid branch hours.', '', array('response' => 422));
                    $hours[(string) $day][] = array($start, $end);
                }
            }
        }
        $names = array_values(array_unique(array_filter(array_map('sanitize_text_field', preg_split('/\r\n|\r|\n/', (string) wp_unslash($_POST['pharmacists'] ?? ''))))));
        $known_codes = $original ? (json_decode((string) ($original['pharmacist_codes_json'] ?? ''), true) ?: array()) : array();
        $known_codes = array_filter($known_codes, static function($pharmacist_name) use ($names) { return in_array($pharmacist_name, $names, true); });
        $data = array('code' => $code, 'name' => $name, 'block_number' => $block, 'lat' => $lat, 'lng' => $lng, 'hours_json' => wp_json_encode($hours), 'pharmacists_json' => wp_json_encode(array_slice($names, 0, 100)), 'pharmacist_codes_json' => wp_json_encode($known_codes), 'updated_at' => current_time('mysql', true));
        foreach (array('phone' => 40, 'whatsapp' => 40, 'address' => 255, 'locality' => 150) as $key => $max) {
            $data[$key] = sanitize_text_field(wp_unslash($_POST[$key] ?? ''));
            if (strlen($data[$key]) > $max) wp_die('Branch contact field is too long.', '', array('response' => 422));
        }
        foreach (array('enabled', 'always_open', 'card_enabled', 'cod_enabled', 'wallet_enabled', 'accept_anywhere') as $key) $data[$key] = isset($_POST[$key]) ? 1 : 0;
        $result = $id ? $wpdb->update(self::table('branches'), $data, array('id' => $id)) : $wpdb->insert(self::table('branches'), $data);
        if ($result === false) wp_die('Could not save branch. Branch code must be unique.', '', array('response' => 409));
        wp_safe_redirect(admin_url('admin.php?page=tabarak-seller-routing&saved=1&branch=' . ($id ?: $wpdb->insert_id)) . '#tsr-branch-editor'); exit;
    }
    public function assign_account() {
        if (!current_user_can('manage_options')) wp_die('Forbidden', '', array('response' => 403));
        check_admin_referer('tsr_account');
        $user = get_userdata(absint($_POST['user_id'] ?? 0)); $branch = self::branch(absint($_POST['branch_id'] ?? 0));
        if (!$user || !in_array('tabarak_seller', (array) $user->roles, true) || !$branch) wp_die('Choose a seller account and branch.', '', array('response' => 422));
        if (strcasecmp($user->user_login, $branch['code']) !== 0) wp_die('The seller username must match this branch code.', '', array('response' => 409));
        $linked = (int) get_user_meta($user->ID, self::BRANCH_META, true);
        if ($linked && $linked !== (int) $branch['id']) wp_die('This seller account already belongs to another branch.', '', array('response' => 409));
        foreach (get_users(array('meta_key' => self::BRANCH_META, 'meta_value' => (int) $branch['id'], 'fields' => 'ID')) as $other_id) {
            if ((int) $other_id !== (int) $user->ID) wp_die('Another account is already linked to this branch.', '', array('response' => 409));
        }
        update_user_meta($user->ID, self::BRANCH_META, (int) $branch['id']);
        wp_safe_redirect(admin_url('admin.php?page=tabarak-seller-routing&saved=1')); exit;
    }
    public function manual_assign() {
        if (!current_user_can('manage_woocommerce')) wp_die('Forbidden', '', array('response' => 403));
        $order_id = absint($_POST['order_id'] ?? 0); check_admin_referer('tsr_manual_assign_' . $order_id);
        $order = wc_get_order($order_id); $branch = self::branch(absint($_POST['branch_id'] ?? 0));
        if (!self::is_mobile_order($order) || !$branch || !$branch['enabled']) wp_die('Invalid order or branch.', '', array('response' => 422));
        if (in_array($order->get_status(), array('cancelled', 'failed', 'refunded', 'completed'), true)) wp_die('This order is closed.', '', array('response' => 409));
        $payment = TSR_Planner::payment_kind($order);
        if (empty($branch[$payment . '_enabled'])) wp_die('This branch cannot receive this payment method.', '', array('response' => 422));
        if ($payment === 'card' && !self::card_paid($order)) wp_die('Card payment is not confirmed.', '', array('response' => 409));
        if ($payment === 'wallet' && !self::wallet_paid($order)) wp_die('Wallet payment is not confirmed.', '', array('response' => 409));
        global $wpdb; $now = current_time('mysql', true);
        $wpdb->query('START TRANSACTION');
        $changed = $wpdb->query($wpdb->prepare('UPDATE ' . self::table('dispatch') . " SET state='claimed',branch_id=%d,claimed_by=%d,claimed_at=%s,updated_at=%s WHERE order_id=%d AND state IN ('needs_location','waiting_for_open','needs_admin','pending')", (int) $branch['id'], get_current_user_id(), $now, $now, $order_id));
        if ($changed !== 1) { $wpdb->query('ROLLBACK'); wp_die('Order was already assigned or changed.', '', array('response' => 409)); }
        $wpdb->query($wpdb->prepare('UPDATE ' . self::table('offers') . " SET state='closed' WHERE order_id=%d AND state='open'", $order_id));
        $wpdb->query('COMMIT');
        $order->update_meta_data('_tabarak_seller_branch_id', (int) $branch['id']); $order->save();
        self::event($order_id, 'assigned_by_admin', get_current_user_id(), (int) $branch['id']);
        self::notify_branch((int) $branch['id'], $order_id, 'manual_assignment', 'Order #' . $order->get_order_number() . ' assigned to your branch');
        self::notify_admins($order_id, 'manual_assignment', 'Order #' . $order->get_order_number() . ' assigned to ' . $branch['name']);
        wp_safe_redirect(admin_url('admin.php?page=tabarak-seller-routing&saved=1')); exit;
    }
}

register_activation_hook(__FILE__, array('Tabarak_Seller_Routing', 'activate'));
add_action('plugins_loaded', array('Tabarak_Seller_Routing', 'boot'), 20);
